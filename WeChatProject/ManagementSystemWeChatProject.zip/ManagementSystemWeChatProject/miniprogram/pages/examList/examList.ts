// pages/examList/examList.ts
import { request as httpRequest } from '../../utils/request';

Page({
  data: {
    exams: []
  },

  async onLoad() {
    await this.loadExamList();
  },

  // 加载考试列表
  async loadExamList() {
    try {
      const result = await httpRequest('/student/exam_list', 'GET', {}, {
        'content-type': 'application/json'
      });

      if (result.status === 'success') {
        this.setData({ exams: result.exams });
      } else {
        wx.showToast({ title: result.message || '获取考试列表失败', icon: 'none' });
        if (result.message === '未登录' || result.statusCode === 401) {
          wx.redirectTo({ url: '/pages/login/login' });
        }
      }
    } catch (error) {
      wx.showToast({ title: '获取考试列表失败', icon: 'none' });
    }
  },

  // 跳转到特定考试页面
  takeExam(e: any) {
    const examId = e.currentTarget.dataset.id;
    wx.navigateTo({ url: `/pages/takeExam/takeExam?id=${examId}` }); // 使用 takeExam 页面
  },

  // 注销功能
  onLogout() {
    wx.clearStorageSync();
    wx.redirectTo({ url: '/pages/login/login' });
  }
});





