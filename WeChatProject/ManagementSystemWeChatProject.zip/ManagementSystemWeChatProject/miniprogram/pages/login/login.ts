// pages/login/login.ts
import { request as httpRequest } from '../../utils/request';

Page({
  data: {
    studentId: '',
    password: ''
  },
  onStudentIdInput(e: any) {
    this.setData({ studentId: e.detail.value });
  },
  onPasswordInput(e: any) {
    this.setData({ password: e.detail.value });
  },
  async onLogin() {
    try {
      const result = await httpRequest('/student/login', 'POST', {
        student_id: this.data.studentId,
        password: this.data.password
      }, {
        'content-type': 'application/x-www-form-urlencoded'
      });
      
      if (result.status === 'success') {
        // 保存 session_id
        wx.setStorageSync('session_id', result.session_id);
        // 手动跳转到考试列表页面
        wx.redirectTo({ url: result.redirect_url || '/pages/examList/examList' });
      } else {
        wx.showToast({ title: result.message, icon: 'none' });
      }
    } catch (error) {
      wx.showToast({ title: '登录失败', icon: 'none' });
    }
  }
});






