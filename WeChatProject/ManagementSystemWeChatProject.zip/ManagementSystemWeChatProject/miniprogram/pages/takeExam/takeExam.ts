import { request as httpRequest } from '../../utils/request';

Page({
  data: {
    examId: null,
    exam: { name: '' },
    questions: [] as Array<{ 
      id: number; 
      content: string; 
      question_type: string; 
      options?: Array<{ id: number; text: string }>  // options 是一个可选属性
    }>,
    answers: {} as { [key: number]: any }  // 存储用户的答案
  },

  onLoad(options: any) {
    this.setData({ examId: options.id });
    this.loadExamDetail();
  },

  // 加载考试详情和试题
  async loadExamDetail() {
    try {
      const result = await httpRequest(`/student/exam/${this.data.examId}`, 'GET', {});
      if (result.status === 'success') {
        // 确保 questions 和 options 的数据结构符合 wxml 中的使用
        const formattedQuestions = result.questions.map((question: any) => ({
          id: question.id,
          content: question.content,
          question_type: question.question_type,
          options: question.options || []  // 确保 options 总是数组
        }));
        
        this.setData({
          exam: result.exam,
          questions: formattedQuestions
        });
        
        console.log("Loaded questions:", this.data.questions);  // 调试输出
      } else {
        wx.showToast({ title: result.message || '获取考试详情失败', icon: 'none' });
      }
    } catch (error) {
      console.error("Error fetching exam details:", error);  // 调试信息
      wx.showToast({ title: '获取考试详情失败', icon: 'none' });
    }
  },

  // 记录用户答案
  onAnswerChange(e: any) {
    const questionId = e.currentTarget.dataset.questionId;
    const answer = e.detail.value;

    const question = this.data.questions.find(q => q.id === questionId);
    if (!question) {
      console.warn(`Question with ID ${questionId} not found.`);
      return;
    }

    let formattedAnswer;

    if (question.question_type === '单选题' || question.question_type === '判断题') {
      // 找到选项的文本内容
      const selectedOption = question.options?.find(option => option.id === parseInt(answer));
      formattedAnswer = selectedOption ? { selected_option_id: selectedOption.id, answer_text: selectedOption.id } : answer;
    } else if (question.question_type === '多选题') {
      // 多选题，需要遍历选项以找到对应的文本
      const selectedOptions = Array.isArray(answer) ? answer.map(optId => {
        const option = question.options?.find(o => o.id === parseInt(optId));
        return option ? { id: option.id, text: option.text } : null;
      }).filter(item => item !== null) : [];
      
      formattedAnswer = {
        selected_option_id: selectedOptions.map(option => option!.id).join(","),
        answer_text: selectedOptions.map(option => option!.id).join(",")
      };
    } else {
      // 填空题和主观题直接存储文本
      formattedAnswer = { answer_text: answer };
    }

    this.setData({
      [`answers.${questionId}`]: formattedAnswer
    });
  },

  // 提交答案
  async onSubmit() {
    try {
      const submissionData = { answers: this.data.answers };
      const result = await httpRequest(`/student/exam/${this.data.examId}`, 'POST', submissionData);
      console.info("submitting answers:", submissionData);  // 调试信息
      if (result.status === 'success') {
        wx.showToast({ title: '提交成功', icon: 'success' });
        wx.redirectTo({ url: '/pages/examList/examList' });
      } else {
        wx.showToast({ title: result.message || '提交失败', icon: 'none' });
      }
    } catch (error) {
      console.error("Error submitting answers:", error);  // 调试信息
      wx.showToast({ title: '提交失败', icon: 'none' });
    }
  }
});
