// pages/register/register.ts
import { request as httpRequest } from '../../utils/request';

Page({
  data: {
    studentId: '',
    name: '',
    studentClass: '',
    gender: 0, // 默认性别为第一个选项
    phoneNumber: '',
    password: '',
    confirmPassword: '',
    genderOptions: ['男', '女']  // 性别选项
  },
  onStudentIdInput(e: any) {
    this.setData({ studentId: e.detail.value });
  },
  onNameInput(e: any) {
    this.setData({ name: e.detail.value });
  },
  onClassInput(e: any) {
    this.setData({ studentClass: e.detail.value });
  },
  onGenderChange(e: any) {
    this.setData({ gender: e.detail.value });
  },
  onPhoneNumberInput(e: any) {
    this.setData({ phoneNumber: e.detail.value });
  },
  onPasswordInput(e: any) {
    this.setData({ password: e.detail.value });
  },
  onConfirmPasswordInput(e: any) {
    this.setData({ confirmPassword: e.detail.value });
  },
  async onRegister() {
    if (this.data.password !== this.data.confirmPassword) {
      wx.showToast({ title: '两次输入的密码不一致', icon: 'none' });
      return;
    }
    try {
      const result = await httpRequest('/student/register', 'POST', {
        student_id: this.data.studentId,
        name: this.data.name,
        student_class: this.data.studentClass,
        gender: this.data.genderOptions[this.data.gender],
        phone_number: this.data.phoneNumber,
        password: this.data.password,
        confirm_password: this.data.confirmPassword
      }, {
        'content-type': 'application/x-www-form-urlencoded'  // 设置为表单格式
      });
      if ((result as any).status === 'success') {
        wx.redirectTo({ url: '/pages/login/login' });
      } else {
        wx.showToast({ title: (result as any).message, icon: 'none' });
      }
    } catch (error) {
      wx.showToast({ title: '注册失败', icon: 'none' });
    }
  }
});


