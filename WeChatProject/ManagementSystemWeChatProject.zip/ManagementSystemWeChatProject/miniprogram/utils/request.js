const baseURL = "https://749hptw27901.vicp.fun";

// 格式化表单数据
function formatFormData(data) {
  return Object.keys(data)
    .map(key => `${encodeURIComponent(key)}=${encodeURIComponent(data[key])}`)
    .join('&');
}

const request = (url, method, data, headers = { "content-type": "application/json" }) => {
  // 从本地存储中获取 session_id
  const session_id = wx.getStorageSync('session_id');
  if (session_id) {
    headers['Authorization'] = `${session_id}`;  // 添加 session_id
  }
  headers['X-Requested-By'] = 'WechatMiniProgram';  // 标识小程序请求

  if (headers["content-type"] === "application/x-www-form-urlencoded") {
    data = formatFormData(data);
  }

  return new Promise((resolve, reject) => {
    wx.request({
      url: `${baseURL}${url}`,
      method: method,
      data: data,
      header: headers,
      success: (res) => {
        if (res.statusCode === 200) {
          resolve(res.data);
        } else {
          reject(res.data);
        }
      },
      fail: (err) => {
        reject(err);
      }
    });
  });
};

module.exports = {
  request
};
